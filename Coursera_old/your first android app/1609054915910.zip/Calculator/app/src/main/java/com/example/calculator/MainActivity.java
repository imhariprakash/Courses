package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText number1,number2;
    TextView results;
    Button add,sub,mul,div,clear;
    float value1,value2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        number1 = (EditText)findViewById(R.id.ET1);
        number2 = (EditText)findViewById(R.id.ET2);
        results = (TextView) findViewById(R.id.TVresults);
        add = (Button)findViewById(R.id.btnAdd);
        sub = (Button)findViewById(R.id.btnSub);
        mul = (Button)findViewById(R.id.btnMul);
        div = (Button)findViewById(R.id.btndiv);
        clear = (Button)findViewById(R.id.clear);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    value1 = Float.parseFloat(number1.getText() + "");
                    value2 = Float.parseFloat(number2.getText() + "");
                    results.setText(value1 + value2 + "");
                }
                catch (Exception e)
                {
                    Toast toast = Toast.makeText(getApplicationContext(),"Enter two numbers.",Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    value1 = Float.parseFloat(number1.getText() + "");
                    value2 = Float.parseFloat(number2.getText() + "");
                    results.setText(value1 - value2 + "");
                }
                catch (Exception e)
                {
                    Toast toast = Toast.makeText(getApplicationContext(),"Enter two numbers.",Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    value1 = Float.parseFloat(number1.getText() + "");
                    value2 = Float.parseFloat(number2.getText() + "");
                    results.setText(value1 * value2 + "");
                }
                catch (Exception e)
                {
                    Toast toast = Toast.makeText(getApplicationContext(),"Enter two numbers.",Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    value1 = Float.parseFloat(number1.getText() + "");
                    value2 = Float.parseFloat(number2.getText() + "");
                    results.setText(value1 / value2 + "");
                }
                catch (Exception e)
                {
                    Toast toast = Toast.makeText(getApplicationContext(),"Enter two numbers.",Toast.LENGTH_SHORT);
                    toast.show();
                }

            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number1.setText("");
                number2.setText("");
                results.setText("");
            }
        });
        class custom_exception extends  Exception{
            custom_exception(String msg)
            {
                super(msg);
            }
        }
        class generate_exception
        {
            void action(String a, String b) throws custom_exception
            {
                if(a.equals("") || b.equals(""))
                {
                    throw new custom_exception("Enter valid numbers..");
                }
                else if(a.equals("") && b.equals(""))
                {
                    throw new custom_exception("Enter two valid numbers...");
                }
                else
                {
                    results.setText(a+b);
                }
            }
        }
    }
}
