var express = require('express');
var app = express();

var faker = require('faker');
var mysql = require('mysql');


app.set('view engine', 'ejs');

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'webapp'
});

app.get('/', function(req, res) {
    console.log("request received for home");
    var q = "SELECT COUNT(*) AS count FROM users";
    connection.query(q, function(err, results) {
        if (err) throw err;
        var count = results[0].count;
        res.render("home", { user_count: count });
        //res.send("We have " + count + " users in our db");
    });
});

app.post('/register', function(req, res) {

})

app.listen(3000, function() {
    console.log('Example app listening on port 8080!');
});