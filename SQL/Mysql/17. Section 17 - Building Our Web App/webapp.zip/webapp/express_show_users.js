var express = require('express');
var app = express();

var faker = require('faker');
var mysql = require('mysql');

app.set('view engine', 'ejs');

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'imhari',
    database: 'webapp'
});

app.get('/', function(req, res) {
    console.log("request received for home");
    var q = "SELECT COUNT(*) AS count FROM users";
    connection.query(q, function(err, results) {
        if (err) throw err;
        var count = results[0].count;
        res.send("We have " + count + " users in our db");
    });
});

app.get('/joke', function(req, res) {
    console.log("request received for joke");
    res.send('WELCOME TO JOKE PAGE');
});

app.get('/random_number', function(req, res) {
    console.log("request received for random number");
    res.send('WELCOME TO RANDOM NUMBER PAGE<br><br>' + "Your lucky number is: " + Math.floor(Math.random() * 10));
});

app.listen(3000, function() {
    console.log('Example app listening on port 8080!');
});