function fh = get_anon_handle(c)
    
    fh = @(x) c*x;
    
end