classdef Contact
    properties
        FirstName
        LastName
        PhoneNumber
    end
end


            